These template codes show fragments of client programs.
So the package is incomplete.
It will not compile and run as they are.
Use these templates for your reference only.

In order to run the login.py file you will need to run the Main.py file