to run the database on local machine you will need to install
mysql server and then use the sql file to create the schema.
When you make the user for the server the:
	username: csula
	password: abcd
good luck it should all be working.