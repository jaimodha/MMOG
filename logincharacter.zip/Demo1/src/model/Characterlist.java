package model;

import java.util.ArrayList;

public class Characterlist {

	    public static ArrayList<UserModel> characterlist ;
		boolean in = false;
		
		public Characterlist()
		{
			 
		}

}
