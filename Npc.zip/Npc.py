'''
Created on Nov 14, 2014

@author: Akshay
'''
#from npc import ControlPoint
from direct.actor.Actor import Actor
from panda3d.ai import *
from panda3d.core import CollisionTraverser,CollisionNode
from panda3d.core import CollisionHandlerQueue,CollisionRay
from panda3d.core import Filename,AmbientLight,DirectionalLight
from direct.interval.LerpInterval import LerpPosInterval
from direct.interval.LerpInterval import *
from libpanda import Point3
from direct.interval.ActorInterval import ActorInterval

class Npc():


    def __init__(self,controlPointId,id, anchorx, anchory, anchorz,render):
        self.id = id
        self.anchorx = anchorx
        self.anchory = anchory
        self.anchorz = anchorz
        self.controlPointId = controlPointId
        self.target = None
        self.isMoving = False
        self.health = 100
        
        
        
        self.render = render
        '''Initializing NPC actors'''
        self.npc = Actor("models/model",
                                {"walk": "models/model-walk"})
        self.npcTex = loader.loadTexture("models/priest_texture.png")
        self.npc.setTexture(self.npcTex)
        self.npc.setScale(0.2, 0.2, 0.2)
        self.npc.reparentTo(self.render)
        self.npc.setPos(anchorx,anchory,anchorz)
        
        self.AIchar = AICharacter("npc",self.npc, 100, 0.05, 5)
        self.AIbehaviors = self.AIchar.getAiBehaviors()
        '''self.AIworld.addAiChar(self.AIchar)''' #this should be in npc controller
        '''self.AIbehaviors = self.AIchar.getAiBehaviors()'''
        
        '''
        self.cTrav = CollisionTraverser()
        self.npcGroundRay = CollisionRay()
        self.npcGroundRay.setOrigin(0,0,1000)
        self.npcGroundRay.setDirection(0,0,-1)
        self.npcGroundCol = CollisionNode('pandaActorRay')
        self.npcGroundCol.addSolid(self.npcGroundRay)
        self.npcGroundCol.setFromCollideMask(BitMask32.bit(0))
        self.npcGroundCol.setIntoCollideMask(BitMask32.allOff())
        self.npcGroundColNp = self.npc.attachNewNode(self.npcGroundCol)
        self.npcGroundHandler = CollisionHandlerQueue()
        self.cTrav.addCollider(self.npcGroundColNp, self.npcGroundHandler)'''
        
    def chaseTarget(self, target):
        
        if(not self.isMoving):
            self.target = target
            self.AIbehaviors.pursue(self.target)
            self.npc.loop("walk")
            self.isMoving = True
            
    def stopChase(self):
        
        self.AIbehaviors.pauseAi("pursue")
        p1 = LerpHprInterval(self.npc, 4, Point3(180,0,0))
        p2 = LerpPosInterval(self.npc, 4, Point3(self.anchorx, self.anchory, self.anchorz))
        animInterval = self.npc.actorInterval("walk", loop = 1, duration=4)
        p2.start()
        p1.start()
        animInterval.start()
        self.isMoving = False
        self.target = None
        
        
        
        