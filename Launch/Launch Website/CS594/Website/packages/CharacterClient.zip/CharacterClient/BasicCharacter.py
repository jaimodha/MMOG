RED = 0
BLUE = 1

class Character():
        
    def __init__(self, name, factionId):
        self.name = name
        self.x = x
        self.y = y
        self.z = z
        self.factionId = factionId